#include "functions.h"

template<typename T>
istream &operator>>(istream &is, vector<T> &vec) {
    // empty vector:
    vec.clear();
    // read length:
    int n;
    cout << "n: ";
    cin >> n;
    // read items
    for (int i = 0; i < n; ++i) {
        T var;
        cin >> var;
        vec.push_back(var);
    }
    return is;
}

template<typename T>
ostream &operator<<(ostream &os, const vector<T> &vec) {
    os << "[ ";
    for(auto& var : vec) {
        os << var << ' ';
    }
    os << ']';

    return os;
}



template<typename T>
ostream &operator<<(ostream &os, const vector<shared_ptr<T> > &vec) {
    os << "[ ";
    for(auto& var : vec) {
        os << *var << ' ';
    }
    os << ']';

    return os;
}
